from django.apps import AppConfig


class ExamenConfig(AppConfig):
    name = 'Examen'
