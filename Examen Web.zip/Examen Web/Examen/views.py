from django.shortcuts import render
from django.http import HttpResponse
from .models import Usuario, Producto, Lista, Tienda
from django.shortcuts import redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, logout, login as auth_login
from django.contrib.auth.decorators import login_required

# IMPORTS


########################################
###    M O N O S - S O F T W A R E   ###
########################################


# views para visualizar templates

def index(request):
    username = request.session.get('username', None)
    return render (request, 'index.html', {'username':Usuario.objects.all()})

def registro(request):
    return render (request, 'regist.html', {})

def login(request):
    return render (request, 'login.html', {})

# --------------- FIN------------------------ #

# ----------- inicio metodos ------ #

#Registro de usuario
def regist(request):
    
    username = request.POST.get('username','')
    password = request.POST.get('password','')
    usuario = Usuario( username = username, password = password )
    usuario.save()
    return redirect('login')

#inicio de sesion de usuarios
def iniciar_sesion(request):
    password = request.POST.get('password', '')
    username = request.POST.get('username','')
    usuario = authenticate(request, password = password, username = username)
    print(usuario)
    if usuario is not None:
        auth_login(request, usuario)
        return redirect('index')
    else:
        return redirect('login')

#cerrar sesion
def cerrar_sesion(request):
    logout(request)
    return redirect('index')

#########################################################

def addTienda(request):
    nombre = request.POST.get('nombre','')
    num_sucursal = request.POST.get('num_sucursal','')
    direccion = request.POST.get('direccion','')
    ciudad = request.POST.get('ciudad', '')
    region = request.POST.get('region','')
    tienda = Tienda(nombre = nombre, num_sucursal = num_sucursal, direccion = direccion,
    ciudad = ciudad, region = region, tienda = tienda)
    tienda.save()
    return redirect('index')