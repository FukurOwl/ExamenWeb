from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    path('registro', views.registro, name="registro"),
    path('registro/succes', views.regist, name="regist"),
    path('login', views.login, name="login"),
    path('login/auth', views.iniciar_sesion, name="iniciar_sesion"),
]